COMO GERAR O APK PELO GITHUB

1. Crie um repositório no GitHub.
2. Envie TODOS os arquivos desta pasta para o repositório.
3. Abra a aba Actions.
4. Se aparecer o workflow "Gerar APK", abra-o e aguarde terminar.
5. Entre na execução concluída e procure a seção Artifacts.
6. Baixe "JogoComSenha-apk".
7. Dentro do ZIP baixado estará o app-debug.apk.

Também é possível gerar automaticamente quando houver um push na branch main ou master.

Senha do aplicativo: Anderson123456

O APK gerado é um APK de debug para instalação/teste. Para publicar na Play Store, será necessário gerar uma versão assinada (release).

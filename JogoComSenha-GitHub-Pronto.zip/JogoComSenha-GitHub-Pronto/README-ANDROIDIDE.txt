JOGO COM SENHA - PROJETO PREPARADO

Senha do jogo: Anderson123456

Para gerar o APK no AndroidIDE:
1. Extraia este ZIP para uma pasta no celular.
2. Abra o AndroidIDE e escolha Import/Open Project.
3. Selecione a pasta JogoComSenha (a pasta que contém settings.gradle).
4. Aguarde a sincronização do Gradle.
5. Se o AndroidIDE pedir o SDK, instale Android SDK Platform 35 e Build Tools compatíveis.
6. Use Build > Assemble Debug (ou a opção equivalente) para gerar o APK de teste.
7. O APK normalmente ficará em app/build/outputs/apk/debug/app-debug.apk.

Observação: o projeto usa Android Gradle Plugin 8.5.2 e Gradle 8.7, uma combinação adequada para ambientes AndroidIDE que suportem AGP moderno.

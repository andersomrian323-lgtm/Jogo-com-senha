package com.example.jogocomsenha;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
public class MainActivity extends Activity {
    private static final String SENHA = "Anderson123456";
    public void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_main);
        EditText p=findViewById(R.id.password); Button e=findViewById(R.id.enter); TextView s=findViewById(R.id.status);
        e.setOnClickListener(v -> {
            if (SENHA.equals(p.getText().toString())) {
                s.setText("Acesso liberado! Jogo iniciado.");
                p.setVisibility(View.GONE); e.setVisibility(View.GONE);
            } else s.setText("Senha incorreta.");
        });
    }
}